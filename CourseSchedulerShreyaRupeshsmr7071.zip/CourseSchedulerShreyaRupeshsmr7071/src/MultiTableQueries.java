/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
/**
 *
 * @author Shreya Rupesh
 */
public class MultiTableQueries {
    private static Connection connection;
    private static ArrayList<ClassDescription> classDescriptions = new ArrayList<ClassDescription>();
    private static PreparedStatement getAllClassDescriptions;
    private static PreparedStatement getScheduledStudentsbyClassCode;
    private static PreparedStatement getWaitlistedStudentsbyClassCode;
    private static ResultSet resultSet;
    
    public static ArrayList<ClassDescription> getAllClassDescriptions(String semester)
    {
        connection = DBConnection.getConnection();
        ArrayList<ClassDescription> classDescriptions = new ArrayList<ClassDescription>();
        try
        {
            getAllClassDescriptions = connection.prepareStatement("select app.class.courseCode, description, seats from app.class, app.course where semester = ? and app.class.courseCode = app.course.courseCode order by app.class.courseCode");
            getAllClassDescriptions.setString(1, semester);
            resultSet = getAllClassDescriptions.executeQuery();
            
            while(resultSet.next())
            {
                String courseCode = resultSet.getString(1);
                String description = resultSet.getString(2);
                int seats = resultSet.getInt(3);
                classDescriptions.add(new ClassDescription(courseCode, description, seats));
            }
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
        return classDescriptions;
    }
    public static ArrayList<StudentEntry> getScheduledStudentsbyClassCode(String courseCode, String semester){
        connection = DBConnection.getConnection();
        ArrayList<StudentEntry> students = new ArrayList<StudentEntry>();

        try
        {
            getScheduledStudentsbyClassCode = connection.prepareStatement("SELECT APP.STUDENT.STUDENTID, APP.STUDENT.FIRSTNAME, APP.STUDENT.LASTNAME FROM APP.SCHEDULE, APP.STUDENT where APP.SCHEDULE.COURSECODE = ? and APP.SCHEDULE.SEMESTER = ? and APP.SCHEDULE.STATUS = 's' and APP.SCHEDULE.STUDENTID = APP.STUDENT.STUDENTID order by APP.SCHEDULE.TIMESTAMP");
            getScheduledStudentsbyClassCode.setString(1, courseCode);
            getScheduledStudentsbyClassCode.setString(2, semester);
            resultSet = getScheduledStudentsbyClassCode.executeQuery();

            while(resultSet.next()){
                String studentID = resultSet.getString(1);
                String firstName = resultSet.getString(2);
                String lastName = resultSet.getString(3);
                students.add(new StudentEntry(studentID, firstName, lastName));
            }

        }
        catch(SQLException sqlException)
        {
        sqlException.printStackTrace();
        }
        return students;
    }
    public static ArrayList<StudentEntry> getWaitlistedStudentsbyClassCode(String courseCode, String semester){
        connection = DBConnection.getConnection();
        ArrayList<StudentEntry> students = new ArrayList<StudentEntry>();

        try
        {
            getWaitlistedStudentsbyClassCode = connection.prepareStatement("SELECT APP.STUDENT.STUDENTID, APP.STUDENT.FIRSTNAME, APP.STUDENT.LASTNAME FROM APP.SCHEDULE, APP.STUDENT where APP.SCHEDULE.COURSECODE = ? and APP.SCHEDULE.SEMESTER = ? and APP.SCHEDULE.STATUS = 'w' and APP.SCHEDULE.STUDENTID = APP.STUDENT.STUDENTID order by APP.SCHEDULE.TIMESTAMP");
            getWaitlistedStudentsbyClassCode.setString(1, courseCode);
            getWaitlistedStudentsbyClassCode.setString(2, semester);
            resultSet = getWaitlistedStudentsbyClassCode.executeQuery();

            while(resultSet.next()){
                String studentID = resultSet.getString(1);
                String firstName = resultSet.getString(2);
                String lastName = resultSet.getString(3);
                students.add(new StudentEntry(studentID, firstName, lastName));
            }

        }
        catch(SQLException sqlException)
        {
        sqlException.printStackTrace();
        }
        return students;
    }
}

